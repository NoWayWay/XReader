package com.example.reader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.launch
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReaderApp() }
    }
}

data class Book(val uri: Uri, val title: String, val format: String, val body: String)

@Composable
fun ReaderApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var books by remember { mutableStateOf(listOf<Book>()) }
    var current by remember { mutableStateOf<Book?>(null) }
    var dark by remember { mutableStateOf(true) }
    var pageMode by remember { mutableStateOf(true) }
    var firstWord by remember { mutableStateOf(false) }
    var fontSize by remember { mutableFloatStateOf(20f) }
    var page by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val openBook = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            kotlinx.coroutines.MainScope().launch {
                try {
                    val loaded = withContext(Dispatchers.IO) { BookLoader.load(context, uri) }
                    books = (books.filterNot { it.uri == uri } + loaded)
                    current = loaded
                    page = 0
                } catch (e: Exception) { error = e.message ?: "Не удалось открыть файл" }
            }
        }
    }

    val bg = if (dark) Color(0xFF17171D) else Color(0xFFF5F0E6)
    val fg = if (dark) Color(0xFFE8E5DE) else Color(0xFF292720)

    MaterialTheme(colorScheme = if (dark) darkColorScheme(background = bg, surface = bg, onBackground = fg, onSurface = fg, primary = Color(0xFFB8AEFF)) else lightColorScheme(background = bg, surface = bg, onBackground = fg, onSurface = fg, primary = Color(0xFF6254C7))) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            if (current == null) {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Book, null, tint = fg, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(12.dp))
                        Text("Моя библиотека", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = fg)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Настройки", tint = fg) }
                    }
                    Spacer(Modifier.height(22.dp))
                    if (books.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Book, null, tint = fg.copy(alpha = .35f), modifier = Modifier.size(58.dp))
                                Spacer(Modifier.height(12.dp))
                                Text("Здесь пока пусто", color = fg, fontSize = 19.sp)
                                Text("Добавь первую книгу", color = fg.copy(alpha = .6f))
                            }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(books) { book ->
                                Card(Modifier.fillMaxWidth().clickable { current = book; page = 0 }, colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF24242C) else Color.White)) {
                                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Book, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                                        Spacer(Modifier.width(14.dp))
                                        Column(Modifier.weight(1f)) { Text(book.title, color = fg, fontWeight = FontWeight.SemiBold); Text(book.format.uppercase(), color = fg.copy(alpha = .55f), fontSize = 12.sp) }
                                    }
                                }
                            }
                        }
                    }
                    Button(onClick = { openBook.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Добавить книгу")
                    }
                }
            } else {
                ReaderScreen(book = current!!, dark = dark, fg = fg, bg = bg, pageMode = pageMode, firstWord = firstWord, fontSize = fontSize, page = page,
                    onPage = { page = it }, onBack = { current = null }, onSettings = { showSettings = true })
            }

            if (showSettings) {
                AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Настройки чтения") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SettingSwitch("Тёмная тема", dark) { dark = it }
                            SettingSwitch("Постраничное чтение", pageMode) { pageMode = it; page = 0 }
                            SettingSwitch("Выделять первое слово предложения", firstWord) { firstWord = it }
                            Text("Размер шрифта: ${fontSize.toInt()}", color = fg)
                            Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 15f..32f)
                        }
                    }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Готово") } })
            }
            error?.let { msg -> AlertDialog(onDismissRequest = { error = null }, title = { Text("Не удалось открыть книгу") }, text = { Text(msg) }, confirmButton = { TextButton(onClick = { error = null }) { Text("ОК") } }) }
        }
    }
}

@Composable fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f), fontSize = 14.sp); Switch(checked, onChange) }
}

@Composable
fun ReaderScreen(book: Book, dark: Boolean, fg: Color, bg: Color, pageMode: Boolean, firstWord: Boolean, fontSize: Float, page: Int, onPage: (Int) -> Unit, onBack: () -> Unit, onSettings: () -> Unit) {
    val chunks = remember(book.body) { paginate(book.body, 1800) }
    val maxPage = (chunks.size - 1).coerceAtLeast(0)
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = fg) }
            Text(book.title, Modifier.weight(1f), color = fg, maxLines = 1, fontWeight = FontWeight.Medium)
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Настройки", tint = fg) }
        }
        if (pageMode) {
            val scrollState = remember(page) { ScrollState(0) }
            var overscroll by remember(page) { mutableFloatStateOf(0f) }
            val pageTurnConnection = remember(page, maxPage, scrollState.value, scrollState.maxValue) {
                object : NestedScrollConnection {
                    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                        if (scrollState.value >= scrollState.maxValue && available.y < 0f) {
                            overscroll += -available.y
                            if (overscroll > 55f) { onPage((page + 1).coerceAtMost(maxPage)); overscroll = 0f }
                        } else if (scrollState.value == 0 && available.y > 0f) {
                            overscroll += available.y
                            if (overscroll > 55f) { onPage((page - 1).coerceAtLeast(0)); overscroll = 0f }
                        } else if (available.y == 0f) overscroll = 0f
                        return Offset.Zero
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().nestedScroll(pageTurnConnection)) {
                Column(Modifier.fillMaxSize().verticalScroll(scrollState).padding(horizontal = 26.dp, vertical = 22.dp)) {
                    Text(buildReaderText(chunks.getOrElse(page) { "" }, firstWord), color = fg, fontSize = fontSize.sp, lineHeight = (fontSize * 1.55f).sp)
                    Spacer(Modifier.height(24.dp))
                    Text("${page + 1} / ${chunks.size}", Modifier.fillMaxWidth(), color = fg.copy(alpha = .45f), textAlign = TextAlign.Center, fontSize = 12.sp)
                }
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 22.dp)) {
                Text(buildReaderText(book.body, firstWord), color = fg, fontSize = fontSize.sp, lineHeight = (fontSize * 1.55f).sp)
            }
        }
        if (pageMode) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onPage((page - 1).coerceAtLeast(0)) }, enabled = page > 0) { Text("Назад") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { onPage((page + 1).coerceAtMost(maxPage)) }, enabled = page < maxPage) { Text("Далее") }
            }
        }
    }
}

fun paginate(text: String, target: Int): List<String> {
    if (text.isBlank()) return listOf("")
    val paragraphs = text.split(Regex("\\n\\s*\\n"))
    val result = mutableListOf<String>(); var current = StringBuilder()
    for (p in paragraphs) {
        val words = p.trim().split(Regex("\\s+"))
        for (word in words) {
            if (current.length + word.length + 1 > target && current.isNotEmpty()) { result.add(current.toString().trim()); current = StringBuilder() }
            current.append(word).append(' ')
        }
        current.append("\n\n")
    }
    if (current.isNotEmpty()) result.add(current.toString().trim())
    return result
}

fun buildReaderText(text: String, enabled: Boolean) = buildAnnotatedString {
    if (!enabled) { append(text); return@buildAnnotatedString }
    val regex = Regex("(^|[.!?…]\\s+)([\\p{L}\\p{N}«“\"(—-][^\\s]*)")
    var last = 0
    regex.findAll(text).forEach { m ->
        append(text.substring(last, m.range.first))
        append(m.groupValues[1])
        pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
        append(m.groupValues[2])
        pop()
        last = m.range.last + 1
    }
    append(text.substring(last))
}
