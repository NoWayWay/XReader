package com.example.reader

import android.content.Context
import android.net.Uri
import org.jsoup.Jsoup
import java.util.zip.ZipInputStream
import java.io.ByteArrayInputStream

object BookLoader {
    fun load(context: Context, uri: Uri): Book {
        val name = queryName(context, uri) ?: "Новая книга"
        val ext = name.substringAfterLast('.', "").lowercase()
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Файл недоступен")
        val text = when (ext) {
            "txt", "text", "md" -> bytes.toString(Charsets.UTF_8)
            "html", "htm" -> Jsoup.parse(bytes.toString(Charsets.UTF_8)).text()
            "rtf" -> decodeRtf(bytes.toString(Charsets.UTF_8))
            "docx" -> readDocx(bytes)
            "fb2" -> Jsoup.parse(bytes.toString(Charsets.UTF_8), org.jsoup.parser.Parser.xmlParser()).text()
            "epub" -> readEpub(bytes)
            "pdf" -> error("PDF пока не поддерживается в этой версии. Для PDF нужен отдельный просмотрщик, чтобы сохранить исходную вёрстку.")
            else -> error("Формат .$ext пока не поддерживается. Сейчас доступны TXT, FB2, EPUB, HTML, MD, RTF и DOCX.")
        }
        return Book(uri, name.substringBeforeLast('.', name), ext.ifBlank { "text" }, text)
    }

    private fun readEpub(bytes: ByteArray): String {
        val entries = mutableListOf<Pair<String, String>>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && (entry.name.endsWith(".xhtml") || entry.name.endsWith(".html") || entry.name.endsWith(".htm"))) {
                    val content = zip.readBytes().toString(Charsets.UTF_8)
                    entries.add(entry.name to Jsoup.parse(content).text())
                }
                zip.closeEntry()
            }
        }
        if (entries.isEmpty()) error("В EPUB не найдены текстовые главы")
        return entries.sortedBy { it.first }.joinToString("\n\n") { it.second }
    }


    private fun readDocx(bytes: ByteArray): String {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    val doc = Jsoup.parse(xml, "", org.jsoup.parser.Parser.xmlParser())
                    return doc.getElementsByTag("w:p").joinToString("\n\n") { paragraph ->
                        paragraph.getElementsByTag("w:t").joinToString("") { it.text() }
                    }.trim()
                }
                zip.closeEntry()
            }
        }
        error("В DOCX не найден основной текст документа")
    }

    private fun decodeRtf(rtf: String): String {
        return rtf
            .replace(Regex("\\\\'[0-9a-fA-F]{2}"), " ")
            .replace(Regex("\\\\[a-zA-Z]+-?\\d* ?"), " ")
            .replace(Regex("[{}]"), "")
            .replace(Regex("\\\\\\"), "\\")
            .replace(Regex("[ \t]+"), " ")
            .trim()
    }

    private fun queryName(context: Context, uri: Uri): String? = context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
}
